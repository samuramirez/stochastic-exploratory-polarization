
#!/bin/bash


gcc main.c functions.c parameters.c -lm -o run

#for N in 10 
for N in  16 32 64 128 256 
do

for ktype in 0 1 4 
do

for nA0 in   2000
do

for kaDeff  in  50 
do

for kd  in 0  1 10
do

#./run $N $ktype $nA0 $kaDeff $kd
sbatch -t 12:00:00 -n 1  --wrap="./run $N $ktype $nA0 $kaDeff $kd"

done
done	
done	
done	
done	
